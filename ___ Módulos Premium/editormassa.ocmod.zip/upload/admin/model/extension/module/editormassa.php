<?php
class ModelExtensionModuleEditormassa extends Model
{
	public function editMassProducts($product_id, $data_new)
	{

		if ($data_new['editormassa_type'] == 'selecteds') {
			if (isset($data_new['status_new'])) {
				$this->changeStatusNew($product_id, $data_new['status_new']);
			}

			if (isset($data_new['product_category_new'])) {
				foreach ($data_new['product_category_new'] as $category_id) {
					$this->changeCategoriesNew($product_id, $category_id);
				}
			}

			if (isset($data_new['product_category_remove'])) {
				$this->changeCategoriesDelete($product_id, $data_new['product_category_remove']);
			}

			if (isset($data_new['manufacturer_new_id'])) {
				$this->changeManufacturerNew($product_id, $data_new['manufacturer_new_id']);
			}

			if (isset($data_new['price_new'])) {
				$this->changePriceNew($product_id, $data_new['price_new'], $data_new['price_type']);
			}

			if (isset($data_new['quantity_new'])) {
				$this->changeQuantityNew($product_id, $data_new['quantity_new'], $data_new['quantity_type']);
			}

			if (isset($data_new['weight_new'])) {
				$this->changeWeightNew($product_id, $data_new['weight_new'], $data_new['weight_type']);
			}

			if (isset($data_new['weight_class_new_id'])) {
				$this->changeWeightClassNew($product_id, $data_new['weight_class_new_id']);
			}

			if (isset($data_new['product_discount_new'])) {
				$this->changeDiscountNew($product_id, $data_new['product_discount_new']);
			}

			if (isset($data_new['product_discount_remove'])) {
				$this->changeDiscountDelete($product_id, $data_new['product_discount_remove']);
			}

			if (isset($data_new['product_special_new'])) {
				$this->changePriceSpecialNew($product_id, $data_new['product_special_new']);
			}

			if (isset($data_new['product_special_remove'])) {
				$this->changePriceSpecialDelete($product_id, $data_new['product_special_remove']);
			}			

			if (isset($data_new['product_option_new'])) {
				$this->changeOptionsNew($product_id, $data_new['product_option_new']);
			}

			if (isset($data_new['product_options_remove'])) {
				$this->changeOptionsDelete($product_id, $data_new['product_options_remove']);
			}

		} else if ($data_new['editormassa_type'] == 'categories') {

			foreach ($data_new['product_category'] as $category_id) {
				$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE category_id = '" . (int)$category_id . "'");
				foreach ($query->rows as $result) {
					$product_id = $result['product_id'];

					if (isset($data_new['status_new'])) {
						$this->changeStatusNew($product_id, $data_new['status_new']);
					}

					if (isset($data_new['product_category_new'])) {
						foreach ($data_new['product_category_new'] as $category_id) {
							$this->changeCategoriesNew($product_id, $category_id);
						}
					}

					if (isset($data_new['product_category_remove'])) {
						$this->changeCategoriesDelete($product_id, $data_new['product_category_remove']);
					}

					if (isset($data_new['manufacturer_new_id'])) {
						$this->changeManufacturerNew($product_id, $data_new['manufacturer_new_id']);
					}

					if (isset($data_new['price_new'])) {
						$this->changePriceNew($product_id, $data_new['price_new'], $data_new['price_type']);
					}

					if (isset($data_new['quantity_new'])) {
						$this->changeQuantityNew($product_id, $data_new['quantity_new'], $data_new['quantity_type']);
					}

					if (isset($data_new['weight_new'])) {
						$this->changeWeightNew($product_id, $data_new['weight_new'], $data_new['weight_type']);
					}

					if (isset($data_new['weight_class_new_id'])) {
						$this->changeWeightClassNew($product_id, $data_new['weight_class_new_id']);
					}

					if (isset($data_new['product_discount_new'])) {
						$this->changeDiscountNew($product_id, $data_new['product_discount_new']);
					}

					if (isset($data_new['product_discount_remove'])) {
						$this->changeDiscountDelete($product_id, $data_new['product_discount_remove']);
					}

					if (isset($data_new['product_special_new'])) {
						$this->changePriceSpecialNew($product_id, $data_new['product_special_new']);
					}

					if (isset($data_new['product_special_remove'])) {
						$this->changePriceSpecialDelete($product_id, $data_new['product_special_remove']);
					}

					if (isset($data_new['product_option_new'])) {
						$this->changeOptionsNew($product_id, $data_new['product_option_new']);
					}
	
					if (isset($data_new['product_options_remove'])) {
						$this->changeOptionsDelete($product_id, $data_new['product_options_remove']);
					}
				}
			}
		} else if ($data_new['editormassa_type'] == 'manufacturies') {

			$manufacturer_id = $product_id;

			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product WHERE manufacturer_id = '" . (int)$manufacturer_id . "'");
			foreach ($query->rows as $result) {
				$product_id = $result['product_id'];

				if (isset($data_new['status_new'])) {
					$this->changeStatusNew($product_id, $data_new['status_new']);
				}

				if (isset($data_new['product_category_new'])) {
					foreach ($data_new['product_category_new'] as $category_id) {
						$this->changeCategoriesNew($product_id, $category_id);
					}
				}

				if (isset($data_new['product_category_remove'])) {
					$this->changeCategoriesDelete($product_id, $data_new['product_category_remove']);
				}

				if (isset($data_new['manufacturer_new_id'])) {
					$this->changeManufacturerNew($product_id, $data_new['manufacturer_new_id']);
				}

				if (isset($data_new['price_new'])) {
					$this->changePriceNew($product_id, $data_new['price_new'], $data_new['price_type']);
				}

				if (isset($data_new['quantity_new'])) {
					$this->changeQuantityNew($product_id, $data_new['quantity_new'], $data_new['quantity_type']);
				}

				if (isset($data_new['weight_new'])) {
					$this->changeWeightNew($product_id, $data_new['weight_new'], $data_new['weight_type']);
				}

				if (isset($data_new['weight_class_new_id'])) {
					$this->changeWeightClassNew($product_id, $data_new['weight_class_new_id']);
				}

				if (isset($data_new['product_discount_new'])) {
					$this->changeDiscountNew($product_id, $data_new['product_discount_new']);
				}

				if (isset($data_new['product_discount_remove'])) {
					$this->changeDiscountDelete($product_id, $data_new['product_discount_remove']);
				}

				if (isset($data_new['product_special_new'])) {
					$this->changePriceSpecialNew($product_id, $data_new['product_special_new']);
				}

				if (isset($data_new['product_special_remove'])) {
					$this->changePriceSpecialDelete($product_id, $data_new['product_special_remove']);
				}

				if (isset($data_new['product_option_new'])) {
					$this->changeOptionsNew($product_id, $data_new['product_option_new']);
				}

				if (isset($data_new['product_options_remove'])) {
					$this->changeOptionsDelete($product_id, $data_new['product_options_remove']);
				}
			}
		} else if ($data_new['editormassa_type'] == 'all') {

			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product");
			foreach ($query->rows as $result) {
				$product_id = $result['product_id'];

				if (isset($data_new['status_new'])) {
					$this->changeStatusNew($product_id, $data_new['status_new']);
				}

				if (isset($data_new['product_category_new'])) {
					foreach ($data_new['product_category_new'] as $category_id) {
						$this->changeCategoriesNew($product_id, $category_id);
					}
				}

				if (isset($data_new['product_category_remove'])) {
					$this->changeCategoriesDelete($product_id, $data_new['product_category_remove']);
				}

				if (isset($data_new['manufacturer_new_id'])) {
					$this->changeManufacturerNew($product_id, $data_new['manufacturer_new_id']);
				}

				if (isset($data_new['price_new'])) {
					$this->changePriceNew($product_id, $data_new['price_new'], $data_new['price_type']);
				}

				if (isset($data_new['quantity_new'])) {
					$this->changeQuantityNew($product_id, $data_new['quantity_new'], $data_new['quantity_type']);
				}

				if (isset($data_new['weight_new'])) {
					$this->changeWeightNew($product_id, $data_new['weight_new'], $data_new['weight_type']);
				}

				if (isset($data_new['weight_class_new_id'])) {
					$this->changeWeightClassNew($product_id, $data_new['weight_class_new_id']);
				}

				if (isset($data_new['product_discount_new'])) {
					$this->changeDiscountNew($product_id, $data_new['product_discount_new']);
				}

				if (isset($data_new['product_discount_remove'])) {
					$this->changeDiscountDelete($product_id, $data_new['product_discount_remove']);
				}

				if (isset($data_new['product_special_new'])) {
					$this->changePriceSpecialNew($product_id, $data_new['product_special_new']);
				}

				if (isset($data_new['product_special_remove'])) {
					$this->changePriceSpecialDelete($product_id, $data_new['product_special_remove']);
				}

				if (isset($data_new['product_option_new'])) {
					$this->changeOptionsNew($product_id, $data_new['product_option_new']);
				}

				if (isset($data_new['product_options_remove'])) {
					$this->changeOptionsDelete($product_id, $data_new['product_options_remove']);
				}
			}
		}
	}

	public function changeStatusNew($product_id, $data_new)
	{
		$this->db->query("UPDATE " . DB_PREFIX . "product SET status = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changeManufacturerNew($product_id, $data_new)
	{
		$this->db->query("UPDATE " . DB_PREFIX . "product SET manufacturer_id = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changeQuantityNew($product_id, $data_new, $data_type)
	{
		if ($data_type == '=') {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		} else if ($data_type == '+') {
			$quantity = $this->db->query("SELECT quantity FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$quantity_new = (int)$quantity->row['quantity'] + (int)$data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = '" . $this->db->escape($quantity_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		} else if ($data_type == '-') {
			$quantity = $this->db->query("SELECT quantity FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$quantity_new = (int)$quantity->row['quantity'] - (int)$data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = '" . $this->db->escape($quantity_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		}
	}

	public function changePriceNew($product_id, $data_new, $data_type)
	{
		if ($data_type == '=') {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET price = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		} elseif ($data_type == '+=') {
			$price = $this->db->query("SELECT price FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$price_new = (int)$price->row['price'] + (int)$data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET price = '" . $this->db->escape($price_new) . "' WHERE product_id = '" . (int)$product_id . "'");

			$getPriceSpecial = $this->db->query("SELECT price FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
			if ($getPriceSpecial->rows) {
				$price_special_new = (int)$getPriceSpecial->row['price'] + (int)$data_new;
				$this->db->query("UPDATE " . DB_PREFIX . "product_special SET price = '" . $this->db->escape($price_special_new) . "' WHERE product_id = '" . (int)$product_id . "'");
			}
		} elseif ($data_type == '-=') {
			$price = $this->db->query("SELECT price FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$price_new = (int)$price->row['price'] - (int)$data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET price = '" . $this->db->escape($price_new) . "' WHERE product_id = '" . (int)$product_id . "'");

			$getPriceSpecial = $this->db->query("SELECT price FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
			if ($getPriceSpecial->rows) {
				$price_special_new = (int)$getPriceSpecial->row['price'] - (int)$data_new;
				$this->db->query("UPDATE " . DB_PREFIX . "product_special SET price = '" . $this->db->escape($price_special_new) . "' WHERE product_id = '" . (int)$product_id . "'");
			}
		} elseif ($data_type == '+%') {
			$price = $this->db->query("SELECT price FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$price_new = (int)$price->row['price'] + ((int)$price->row['price'] / 100 * (int)$data_new);
			$this->db->query("UPDATE " . DB_PREFIX . "product SET price = '" . $this->db->escape($price_new) . "' WHERE product_id = '" . (int)$product_id . "'");

			$getPriceSpecial = $this->db->query("SELECT price FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
			if ($getPriceSpecial->rows) {
				$price_special_new = (int)$getPriceSpecial->row['price'] + ((int)$getPriceSpecial->row['price'] / 100 * (int)$data_new);;
				$this->db->query("UPDATE " . DB_PREFIX . "product_special SET price = '" . $this->db->escape($price_special_new) . "' WHERE product_id = '" . (int)$product_id . "'");
			}
		} elseif ($data_type == '-%') {
			$price = $this->db->query("SELECT price FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$price_new = (int)$price->row['price'] - ((int)$price->row['price'] / 100 * (int)$data_new);
			$this->db->query("UPDATE " . DB_PREFIX . "product SET price = '" . $this->db->escape($price_new) . "' WHERE product_id = '" . (int)$product_id . "'");

			$getPriceSpecial = $this->db->query("SELECT price FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
			if ($getPriceSpecial->rows) {
				$price_special_new = (int)$getPriceSpecial->row['price'] - ((int)$getPriceSpecial->row['price'] / 100 * (int)$data_new);;
				$this->db->query("UPDATE " . DB_PREFIX . "product_special SET price = '" . $this->db->escape($price_special_new) . "' WHERE product_id = '" . (int)$product_id . "'");
			}
		}
	}

	public function changeWeightNew($product_id, $data_new, $data_type)
	{
		if ($data_type == '=') {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET weight = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		} else if ($data_type == '+') {
			$weight = $this->db->query("SELECT weight FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$weight_new = $weight->row['weight'] + $data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET weight = '" . $this->db->escape($weight_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		} else if ($data_type == '-') {
			$weight = $this->db->query("SELECT weight FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
			$weight_new = $weight->row['weight'] - $data_new;
			$this->db->query("UPDATE " . DB_PREFIX . "product SET weight = '" . $this->db->escape($weight_new) . "' WHERE product_id = '" . (int)$product_id . "'");
		}
	}

	public function changeWeightClassNew($product_id, $data_new)
	{
		$this->db->query("UPDATE " . DB_PREFIX . "product SET weight_class_id = '" . $this->db->escape($data_new) . "' WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changeDiscountNew($product_id, $data_new)
	{
		$verifyDiscount = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_discount WHERE product_id = '" . (int)$product_id . "'");

		if ($verifyDiscount->num_rows > 0) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_discount WHERE product_id = '" . (int)$product_id . "'");
		}

		foreach ($data_new as $data) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_discount SET product_id = '" . (int)$product_id . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', quantity = '" . $this->db->escape($data['quantity']) . "', priority = '" . $this->db->escape($data['priority']) . "', price = '" . $this->db->escape($data['price']) . "', date_start = '" . $this->db->escape($data['date_start']) . "', date_end = '" . $this->db->escape($data['date_end']) . "'");
		}
	}

	public function changeDiscountDelete($product_id, $data_new)
	{
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_discount WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changePriceSpecialNew($product_id, $data_new)
	{
		$verifyPriceSpecial = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");

		if ($verifyPriceSpecial->num_rows > 0) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
		}

		foreach ($data_new as $data) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_special SET product_id = '" . (int)$product_id . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', priority = '" . $this->db->escape($data['priority']) . "', price = '" . $this->db->escape($data['price']) . "', date_start = '" . $this->db->escape($data['date_start']) . "', date_end = '" . $this->db->escape($data['date_end']) . "'");
		}
	}

	public function changePriceSpecialDelete($product_id, $data_new)
	{
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changeCategoriesNew($product_id, $data_new)
	{
		$verifyCategory = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "' and category_id = '" . (int)$data_new . "'");
		if ($verifyCategory->num_rows == 0) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$data_new . "'");
		}
	}

	public function changeCategoriesDelete($product_id, $data_new)
	{
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "'");
	}

	public function changeOptionsNew($product_id, $data_new)
	{
		foreach ($data_new as $product_option_new) {
			if ($product_option_new['type'] == 'select' || $product_option_new['type'] == 'radio' || $product_option_new['type'] == 'checkbox' || $product_option_new['type'] == 'image') {
				if (isset($product_option_new['product_option_value'])) {
					//verify if existy product_option for this product
					$verify = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option WHERE product_id = '" . (int)$product_id . "' AND  option_id = '" . (int)$product_option_new['option_id'] . "'");
					if ($verify->num_rows == 0) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option_new['option_id'] . "', required = '" . (int)$product_option_new['required'] . "'");
						$product_option_new_id = $this->db->getLastId();
					} else {
						$get_product_option_new_id = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option WHERE product_id = '" . (int)$product_id . "' AND  option_id = '" . (int)$product_option_new['option_id'] . "'");
						$product_option_new_id = $get_product_option_new_id->row['product_option_id'];
					}


					foreach ($product_option_new['product_option_value'] as $product_option_new_value) {
						$verify = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_option_value WHERE product_option_id = '" . (int)$product_option_new_id . "' AND product_id = '" . (int)$product_id . "' AND  option_id = '" . (int)$product_option_new['option_id'] . "' AND option_value_id = '" . (int)$product_option_new_value['option_value_id'] . "'");
						// var_dump($verify);exit;
						if ($verify->num_rows == 0) {
							$this->db->query("INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_new_id . "', product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option_new['option_id'] . "', option_value_id = '" . (int)$product_option_new_value['option_value_id'] . "', quantity = '" . (int)$product_option_new_value['quantity'] . "', subtract = '" . (int)$product_option_new_value['subtract'] . "', price = '" . (float)$product_option_new_value['price'] . "', price_prefix = '" . $this->db->escape($product_option_new_value['price_prefix']) . "', points = '" . (int)$product_option_new_value['points'] . "', points_prefix = '" . $this->db->escape($product_option_new_value['points_prefix']) . "', weight = '" . (float)$product_option_new_value['weight'] . "', weight_prefix = '" . $this->db->escape($product_option_new_value['weight_prefix']) . "'");
						}
					}
				}
			} else {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option_new['option_id'] . "', value = '" . $this->db->escape($product_option_new['value']) . "', required = '" . (int)$product_option_new['required'] . "'");
			}
		}
	}
	
	public function changeOptionsDelete($product_id, $data_new)
	{
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_option WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_option_value WHERE product_id = '" . (int)$product_id . "'");
	}

}
