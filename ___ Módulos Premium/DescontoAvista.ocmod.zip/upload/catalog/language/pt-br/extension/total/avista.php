<?php
$_['text_avista']   = 'Desconto à vista:';
$_['text_discount'] = 'Desconto de ';
?>