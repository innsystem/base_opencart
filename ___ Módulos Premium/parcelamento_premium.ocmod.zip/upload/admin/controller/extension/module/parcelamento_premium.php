<?php
class ControllerExtensionModuleParcelamentoPremium extends Controller
{
    private $error = array();

    public function index()
    {
        $this->load->language('extension/module/parcelamento_premium');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_parcelamento_premium', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/parcelamento_premium', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/parcelamento_premium', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        // PIX com Desconto
        if (isset($this->request->post['module_parcelamento_premium_pix'])) {
            $data['module_parcelamento_premium_pix'] = $this->request->post['module_parcelamento_premium_pix'];
        } else {
            $data['module_parcelamento_premium_pix'] = $this->config->get('module_parcelamento_premium_pix');
        }

        if (isset($this->request->post['module_parcelamento_premium_pix_desconto'])) {
            $data['module_parcelamento_premium_pix_desconto'] = $this->request->post['module_parcelamento_premium_pix_desconto'];
        } else {
            $data['module_parcelamento_premium_pix_desconto'] = $this->config->get('module_parcelamento_premium_pix_desconto');
        }
        
        // Boleto com Desconto
        if (isset($this->request->post['module_parcelamento_premium_boleto'])) {
            $data['module_parcelamento_premium_boleto'] = $this->request->post['module_parcelamento_premium_boleto'];
        } else {
            $data['module_parcelamento_premium_boleto'] = $this->config->get('module_parcelamento_premium_boleto');
        }

        if (isset($this->request->post['module_parcelamento_premium_boleto_desconto'])) {
            $data['module_parcelamento_premium_boleto_desconto'] = $this->request->post['module_parcelamento_premium_boleto_desconto'];
        } else {
            $data['module_parcelamento_premium_boleto_desconto'] = $this->config->get('module_parcelamento_premium_boleto_desconto');
        }

        
        // Parcelamento cartao
        if (isset($this->request->post['module_parcelamento_premium_cartao'])) {
            $data['module_parcelamento_premium_cartao'] = $this->request->post['module_parcelamento_premium_cartao'];
        } else {
            $data['module_parcelamento_premium_cartao'] = $this->config->get('module_parcelamento_premium_cartao');
        }

        if (isset($this->request->post['module_parcelamento_premium_total_parcelas'])) {
            $data['module_parcelamento_premium_total_parcelas'] = $this->request->post['module_parcelamento_premium_total_parcelas'];
        } else {
            $data['module_parcelamento_premium_total_parcelas'] = $this->config->get('module_parcelamento_premium_total_parcelas');
        }

        if (isset($this->request->post['module_parcelamento_premium_parcelas_sem_juros'])) {
            $data['module_parcelamento_premium_parcelas_sem_juros'] = $this->request->post['module_parcelamento_premium_parcelas_sem_juros'];
        } else {
            $data['module_parcelamento_premium_parcelas_sem_juros'] = $this->config->get('module_parcelamento_premium_parcelas_sem_juros');
        }

        if (isset($this->request->post['module_parcelamento_premium_juros_mes'])) {
            $data['module_parcelamento_premium_juros_mes'] = $this->request->post['module_parcelamento_premium_juros_mes'];
        } else {
            $data['module_parcelamento_premium_juros_mes'] = $this->config->get('module_parcelamento_premium_juros_mes');
        }

        if (isset($this->request->post['module_parcelamento_premium_parcela_minima'])) {
            $data['module_parcelamento_premium_parcela_minima'] = $this->request->post['module_parcelamento_premium_parcela_minima'];
        } else {
            $data['module_parcelamento_premium_parcela_minima'] = $this->config->get('module_parcelamento_premium_parcela_minima');
        }

        if (isset($this->request->post['module_parcelamento_premium_status'])) {
            $data['module_parcelamento_premium_status'] = $this->request->post['module_parcelamento_premium_status'];
        } else {
            $data['module_parcelamento_premium_status'] = $this->config->get('module_parcelamento_premium_status');
        }

        if (isset($this->request->post['module_parcelamento_premium_bandeiras_status'])) {
            $data['module_parcelamento_premium_bandeiras_status'] = $this->request->post['module_parcelamento_premium_bandeiras_status'];
        } else {
            $data['module_parcelamento_premium_bandeiras_status'] = $this->config->get('module_parcelamento_premium_bandeiras_status');
        }

        $bandeiras = [
            'visa',
            'mastercard',
            'amex',
            'diners',
            'hipercard',
            'elo',
            'boleto',
            'pix',
            'itau',
            'bradesco',
            'caixa',
            'bancobrasil',
            'santander',
            'paypal',
            'pagseguro',
            'mercadopago',
            'gerencianet',
            'appmax',
        ];

        foreach($bandeiras as $bandeira){
            if (isset($this->request->post['module_parcelamento_premium_bandeira_'.$bandeira])) {
                $data['module_parcelamento_premium_bandeira_'.$bandeira] = $this->request->post['module_parcelamento_premium_bandeira_'.$bandeira];
            } else {
                $data['module_parcelamento_premium_bandeira_'.$bandeira] = $this->config->get('module_parcelamento_premium_bandeira_'.$bandeira);
            }
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/parcelamento_premium', $data));
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/module/parcelamento_premium')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }
}
