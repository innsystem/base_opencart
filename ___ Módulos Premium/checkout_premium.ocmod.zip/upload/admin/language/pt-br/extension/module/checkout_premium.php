<?php
// Heading
$_['heading_title']    = 'Checkout Premium';

// Text
$_['text_success']     = 'Checkout Premium modificado com sucesso!';
$_['text_setting']        = 'Configurarção do Checkout Premium';

// Entry
$_['entry_name'] = 'Título do Módulo';
$_['entry_status']     = 'Situação';

// Help
$_['help_product']     = '(Autocompletar)';

// Success
$_['text_success_recover_orders']     = 'Pedidos Recuperados com Sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Checkout Premium!';
$_['error_name']       = 'Título do módulo deve ter entre 3 e 64 caracteres!';
$_['error_status']      = 'Status do Módulo é obrigatório!';
